/**
 *  \file insertion-sort.cc
 *
 *  \brief Implement your insertion sort in this file.
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include "sort.hh"

/*
left: 		index of the first element in the sub-array to search in
right: 		index of the last element in the sub-array to search in
array: 		pointer to the first element of the original array
element: 	the value to search for

The function will return the index at which element needs to be inserted into array.
*/
unsigned int binarySearch(int left, int right, keytype* array, keytype element) 
{
  // handle base case:
  if (left >= right) {
    if (element <= array[left]) {
      return left;
    } else {
      return right + 1;
    }
  }

  // compute the middle-index:
  int midIndex = left + ( (right - left) / 2);
  // extract the element at middle-index:
  keytype midElement = array[midIndex];
  // check equality:
  if (element < midElement) {
    // search on the left side of the array:
    return binarySearch(left, midIndex - 1, array, element);
  } else {
    // search on the right side of the array:
    return binarySearch(midIndex + 1, right, array, element);
  }
}

void mySort (int N, keytype* A)
{
  for (int j = 1; j < N; j++) {
    // extract key:
    keytype key = A[j];
    // find the right insertion point in A[0..j-1]:
    unsigned int index = binarySearch(0, j-1, A, key);
    // shift elements if needed:
    for (int i = j; i > index; --i) {
      A[i] = A[i-1]; 
    }
    // insert jey at the right index:
    A[index] = key;
  }
}

/* eof */
