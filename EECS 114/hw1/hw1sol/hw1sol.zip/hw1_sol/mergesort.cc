/**
 *  \file mergesort.cc
 *
 *  \brief Implement your mergesort in this file.
 */

#include <iostream>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include "sort.hh"

/* Pre-conditions: is_sorted(begin, mid) and is_sorted(mid, end) */
void merge (int begX, int endX, int begY, int endY, keytype* A, keytype* Atemp)
{
  int i = begX; int j = begY;
  int k = 0;
  while (i < endX && j < endY)
    Atemp[k++] = (A[i] <= A[j]) ? A[i++] : A[j++];
  while (i < endX)
    Atemp[k++] = A[i++];
  while (j < endY)
    Atemp[k++] = A[j++];
}

void mergeSort (int N, keytype* A, keytype* Atemp)
{
  if (N > 1) {
    int mid = N / 2;
    mergeSort(mid, A, Atemp);
    mergeSort(N - mid, A + mid, Atemp + mid);
    merge(0, mid, mid, N, A, Atemp);
    std::copy (Atemp, Atemp + N, A);
  }
}

void mySort (int N, keytype* A)
{
  keytype* Atemp = newKeys (N);
  mergeSort(N, A, Atemp);

  free(Atemp);
}

/* eof */
